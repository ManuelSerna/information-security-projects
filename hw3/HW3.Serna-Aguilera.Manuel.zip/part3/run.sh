#!/bin/bash
python aes_testing.py
python rsa_testing.py

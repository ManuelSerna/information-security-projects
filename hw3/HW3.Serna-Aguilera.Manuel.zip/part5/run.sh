#!/bin/bash
python alice5.py
python bob5.py


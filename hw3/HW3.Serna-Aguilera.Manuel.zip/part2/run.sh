#!/bin/bash
python alice2.py
python bob2.py

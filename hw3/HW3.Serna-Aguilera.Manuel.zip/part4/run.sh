#!/bin/bash
python alice4.py
python bob4.py

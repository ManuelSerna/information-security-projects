#!/bin/bash
python hmac_testing.py
python rsa_sig_test.py

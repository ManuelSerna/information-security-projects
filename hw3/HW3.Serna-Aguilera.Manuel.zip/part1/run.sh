#!/bin/bash
python alice1.py
python bob1.py
